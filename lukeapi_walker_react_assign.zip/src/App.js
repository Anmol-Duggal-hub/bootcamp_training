import React, { useState, useEffect } from 'react';
import './App.css';
import { Link, Router, navigate } from '@reach/router';


import Personpage from './components/Personpage.js';
import Planetpage from './components/Planetpage.js';


function App() {
  const [queryType, setQueryType] = useState("people");
  const [queryId, setQueryId] = useState("");


  const showInfo = (e) => {
    e.preventDefault();
    console.log(queryId);
    console.log(queryType);
    if(queryType === 'people'){
    navigate("/person/" + queryId);
    }
    else if(queryType === 'planet'){
      navigate("/planet/" + queryId);
      }
    else
      return(<div>These aren't the droids you're looking for</div>);
  }

  return (
    <div className="App">
      <div>
        <form onSubmit={ showInfo }>
            <div>
                <label style={{margin: 10}}>Search for:</label>
                <select value={queryType} onChange={ (e) => setQueryType(e.target.value)}>
                    <option value='people'>People</option>
                    <option value='planet'>Planet</option>
                </select>
                <label style={{margin: 10}}>ID:</label>
                <input type="text" onChange={ (e) => setQueryId(e.target.value)}></input>
                <button type="submit">Search</button>
            </div>
        </form>
      </div>

      <Router>
        <Personpage path="/person/:id"/>
        <Planetpage path="/planet/:id"/>
      </Router>
    </div>
  );
}

export default App;

import React, { useEffect, useState} from 'react';
import axios from 'axios';
const id = "1";
axios.get('https://swapi.dev/api/people/' + id)
  .then(response=>{console.log(response.data)})

function Personpage({ id }){
    const [personInfo, setPersonInfo] = useState({});

    useEffect(() => {
        axios.get('https://swapi.dev/api/people/' + id)
            .then(response => setPersonInfo(response.data))
            
    }, []);
    console.log(personInfo);
    JSON.stringify(personInfo);

    return (
        <div>
                <div>
                    <h1>{personInfo.name}</h1>
                    <p>Height: {personInfo.height}</p>
                    <p>Hair Color: {personInfo.hair_color}</p>
                    <p>Eye Color: {personInfo.eye_color}</p>
                    <p>Skin Color: {personInfo.skin_color}</p>
                </div>
        </div>
    )
}

export default Personpage;
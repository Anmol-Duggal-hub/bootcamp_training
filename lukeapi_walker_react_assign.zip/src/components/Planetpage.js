import React, { useEffect, useState} from 'react';
import axios from 'axios';
const id = "1";
axios.get('https://swapi.dev/api/planets/' + id)
  .then(response=>{console.log(response.data)})

function Planetpage({ id }){
    const [planetInfo, setPlanetInfo] = useState({});

    useEffect(() => {
        axios.get('https://swapi.dev/api/planets/' + id)
            .then(response => setPlanetInfo(response.data))
            
    }, []);
    console.log(planetInfo);
    JSON.stringify(planetInfo);

    return (
        <div>
                <div>
                    <h1>{planetInfo.name}</h1>
                    <p>Climate: {planetInfo.climate}</p>
                    <p>Terrain: {planetInfo.terrain}</p>
                    <p>Surface Water: {planetInfo.surface_water}</p>
                    <p>Population: {planetInfo.population}</p>
                </div>
        </div>
    )
}

export default Planetpage;
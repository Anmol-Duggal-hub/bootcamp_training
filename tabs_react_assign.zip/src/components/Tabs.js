import React, {useState} from 'react';

const Tabs = (props) => {
    const tabContent = {
        tab1: "Tab 1 Content is showing here.",
        tab2: "Tab 2 Content is showing here.",
        tab3: "Tab 3 Content is showing here.",
    }

    const [displayContent, setDisplayContent] = useState("");

    const handleClick = (e, num) => {
        if (num === 1){
            setDisplayContent(tabContent.tab1);
        }
        else if (num === 2){
            setDisplayContent(tabContent.tab2);
        }
        else if (num === 3){
            setDisplayContent(tabContent.tab3);
        }
    }

    return(
        <div>
            <button onClick={ (e) => handleClick(e, 1) }>Tab 1</button>
            <button onClick={ (e) => handleClick(e, 2) }>Tab 2</button>
            <button onClick={ (e) => handleClick(e, 3) }>Tab 3</button>
            <div>
                <p>{displayContent}</p>
            </div>
        </div>
    )
}

export default Tabs;
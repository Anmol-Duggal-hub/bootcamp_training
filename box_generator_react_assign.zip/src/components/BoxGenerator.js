import React, { useState } from 'react';

const BoxGenerator = (props) => {
    const [color, setColor] = useState("");
    const [boxArray, setBoxArray] = useState([]);
    const [num, setNum] = useState("");

    const createBox = (e) => {
        e.preventDefault();
        const newNum = parseInt(num);
        const box = {color, newNum};
        setBoxArray([...boxArray, box])
        setColor('');
    }

    return (
    <div>
        <form onSubmit={ createBox }>
            <div>
                <label>Color: </label>
                <input type="text" onChange={ (e) => setColor(e.target.value) } value={ color } />
                <input type="text" onChange={ (e) => setNum(e.target.value) } value={ num } />
                <button>Add</button>
            </div>
        </form>
        <div>
            {boxArray.map((box, i) => {
                return (
                <div style={{margin: 5, display: "inline-block", background: box.color, width: box.newNum, height:box.newNum}}></div>
                );
            })}
        </div>
    </div>


    )
}

export default BoxGenerator;


public class FizzBuzzTest {
    public static void main(String[] args){
        FizzBuzz.fizzBuzz(15);
        FizzBuzz.fizzBuzz(6);
        FizzBuzz.fizzBuzz(20);
        FizzBuzz.fizzBuzz(2);
    }
}

public class Pythagorean {
    public static double calculateHypotensue(int legA, int legB){
        double c = Math.sqrt(legA*legA + legB*legB);
        return c;
    }
}

public class PythaInsta {
    public static void main(String[] args){
       double testPytha = Pythagorean.calculateHypotensue(7, 8);
       System.out.println(testPytha);
    }

}
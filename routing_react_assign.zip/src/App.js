import React from 'react';
import './App.css';

import { Router } from '@reach/router';
import Homepage from './components/Homepage.js';
import Numpage from './components/Numpage.js';
import Stylepage from './components/Stylepage.js';



function App() {
  return (
    <div className="App">
      <Router>
        <Homepage path="/home"/>
        <Numpage path="/:id"/>
        <Stylepage path="/:word/:color1/:color2"/>
      </Router>
    </div>
  );
}

export default App;

import React from 'react';

const Numpage = (props) => {
        if (isNaN(props.id) === false) {
            return(<p>The number is: {props.id}</p>)
        }
        else {
            return(<p>The word is: {props.id}</p>)
        }
}

export default Numpage;
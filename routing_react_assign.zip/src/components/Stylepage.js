import React from 'react';

const Stylepage = (props) => {
    return(
        <p style={{color: props.color1, background: props.color2}}>The word is: {props.word}</p>
    )
}

export default Stylepage;
import React from 'react';
import './App.css';
import PokeList from './components/PokeList.js'

function App() {
  return (
    <div className="App">
      <PokeList/>
    </div>
  );
}

export default App;

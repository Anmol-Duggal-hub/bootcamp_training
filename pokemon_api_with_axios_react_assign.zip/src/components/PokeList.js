import React, {useState, useEffect} from 'react';
import axios from 'axios';


function PokeList() {
    const [pokelist, setPokeList] = useState([]);
    const [showList, setShowList] = useState([]);

    useEffect(() => {
        axios.get("https://pokeapi.co/api/v2/pokemon/?limit=807")
            .then(response => setPokeList(response.data.results));
    }, []);

    const handleClick = e => {
        setShowList([...pokelist])
    }

    return(
        <div>
            <button onClick={handleClick}>Fetch Pokemon</button>
            {showList.map((pokemon, i)=>{
                return (<div key={i}>{pokemon.name}</div>)
            })}
        </div>
    )
}

export default PokeList;
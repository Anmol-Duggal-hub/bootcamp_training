import React from 'react';
import './App.css';
import PersonCard from './components/PersonCard';

function App() {
  return (
    <div className="App">
      <PersonCard firstName="John" lastName="Smith" age={ 8 } hairColor="Brown"/>
      <PersonCard firstName="Jane" lastName="Doe" age={ 22 } hairColor="Black"/>
      <PersonCard firstName="Andy" lastName="Smith" age={ 45 } hairColor="Blonde"/>
      <PersonCard firstName="Jen" lastName="Doe" age={ 33 } hairColor="Blue" />
    </div>
  );
}

export default App;

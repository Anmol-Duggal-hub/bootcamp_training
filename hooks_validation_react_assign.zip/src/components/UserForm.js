import React, {useState} from  'react';

const UserForm = props => {
    const { inputs, setInputs } = props;
    const [firstNameError, setFirstNameError] = useState("");
    const [lastNameError, setLastNameError] = useState("");
    const [emailError, setEmailError] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [confirmPasswordError, setConfirmPasswordError] = useState("");

    const onChange = e => {
        setInputs({
            ...inputs,
            [e.target.name]: e.target.value
        });
        
        if(inputs.firstName.length<2){
            setFirstNameError("First Name must be greater than 2 characters!")
        }
        else {
            setFirstNameError("")
        }
        if(inputs.lastName.length<2){
            setLastNameError("Last Name must be greater than 2 characters!")
        }
        else {
            setLastNameError("")
        }
        if(inputs.email.length<2){
            setEmailError("Email must be greater than 2 characters!")
        }
        else {
            setEmailError("")
        }
        if(inputs.password.length<=8){
            setPasswordError("Password must be at least 8 characters!")
        }
        else {
            setPasswordError("")
        }
        if(inputs.confirmPassword !== inputs.password)
        setConfirmPasswordError("Password and Confirm Password must match!")
        else {
            setConfirmPasswordError("")
        }
    };

    return(
        <form>
            <div>
                <label htmlFor="firstName">First Name: </label>
                <input type="text" onChange={onChange} name= "firstName" />
                <h3>{firstNameError}</h3>
            </div>
            <div>
                <label htmlFor="lastName">Last Name: </label>
                <input type="text" onChange={onChange} name= "lastName" />
                <h3>{lastNameError}</h3>
            </div>
            <div>
                <label htmlFor="email">Email Address: </label>
                <input type="text" onChange={onChange} name= "email"/>
                <h3>{emailError}</h3>
            </div>
            <div>
                <label htmlFor="password">Password: </label>
                <input type="text" onChange={onChange} name= "password"/>
                <h3>{passwordError}</h3>
            </div>
            <div>
                <label htmlFor="confirmPassword">Confirm Password: </label>
                <input type="text" onChange={onChange} name= "confirmPassword"/>
                <h3>{confirmPasswordError}</h3>
            </div>
        </form>
    );
};

export default UserForm;
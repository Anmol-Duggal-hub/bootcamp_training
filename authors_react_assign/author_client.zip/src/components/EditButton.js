import React from 'react';
import { navigate } from '@reach/router';


const EditButton = props => {
    const { authorId } = props;
    const onClickHandler = e => {
        navigate('/edit/' + authorId);
    }

    return (
        <button onClick={onClickHandler}>Edit</button>
    )

}
export default EditButton;
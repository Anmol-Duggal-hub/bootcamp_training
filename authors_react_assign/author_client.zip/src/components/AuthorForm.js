import React, { useState } from 'react'
import { navigate } from '@reach/router';
export default props => {
    const { onSubmitHandler, initialName } = props;
    const [name, setName] = useState(initialName);

    return (
        <div>
            <form onSubmit={e => { onSubmitHandler(e, {name}) }}>
                <p>
                    <label>Name:</label><br/>
                    <input
                    type="text"
                    name="name"
                    value={name}
                    onChange = {(e)=>setName(e.target.value)}/>
                </p>
                <button type="submit">Submit</button>{" "}
                <button onClick={(e)=>navigate("/")}>Cancel</button>
            </form>
        </div>
    )
}
import React from 'react';
import { Link} from '@reach/router';
import DeleteButton from './DeleteButton';
import EditButton from './EditButton';


export default props => {
    return (
        <div>
            <Link to='/new'>Add an Author</Link>
            <p>We have quotes by:</p>
            <table style={{width: "500px", border: "2px black solid"}}>
                <tbody>
                    <tr>
                        <th style={{border: "2px black solid", marign:"5px"}}>Author</th>
                        <th style={{border: "2px black solid"}}>Actions Available</th>
                    </tr>
                        {props.author.map((author, idx)=>{
                                return (
                                    <tr key = {idx}>
                                        <td style={{display:"block"}}>{author.name}</td>
                                        <td><DeleteButton authorId={author._id}/>{' '}<EditButton authorId={author._id}/></td>
                                    </tr>
                                )
                            })}
                </tbody>
            </table>
        </div>
    )
}
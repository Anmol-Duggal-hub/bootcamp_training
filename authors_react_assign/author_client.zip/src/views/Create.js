import React from 'react';
import axios from 'axios';
import AuthorForm from '../components/AuthorForm';
import { Link, navigate } from '@reach/router';


const CreateView = props => {
    const onSubmitHandler = (e, name) => {
        e.preventDefault();
        axios.post('http://localhost:8000/api/author', name)
            .then(response => {
                navigate('/');
            // window.location.reload(false);
        })
        .catch(err => {
            console.log(err);
        })
    }

    return (
        <div>
            <Link to="/">Home</Link>
            <p>Add a new author:</p>
            <AuthorForm onSubmitHandler = {onSubmitHandler} initialName=""/>
        </div>
    )
}

export default CreateView;
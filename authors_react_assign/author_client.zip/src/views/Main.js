import React, { useEffect, useState} from 'react';
import axios from 'axios';
import AuthorList from '../components/AuthorList';
import { navigate } from "@reach/router";

export default () => {
    const [author, setAuthor] = useState([]);
    const [loaded, setLoaded] = useState(false);

    useEffect(() =>{
        axios.get('http://localhost:8000/api/authors')
            .then(res => {
                res.data.sort(function(a, b) {
                    var textA = a.name.toUpperCase();
                    var textB = b.name.toUpperCase();
                    return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
                });
                setAuthor(res.data);
                setLoaded(true);
            });
    }, [])

    const removeFromDom = authorId => {
        setAuthor(author.filter(author => author._id !== authorId))
        navigate('/');
    }

    return (
        <div>
           {loaded && <AuthorList author={author} removeFromDom = {removeFromDom}/>}
        </div>
    )
}
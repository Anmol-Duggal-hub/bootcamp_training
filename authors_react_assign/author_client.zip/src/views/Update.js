import React, { useState, useEffect} from "react";
import AuthorForm from '../components/AuthorForm';
import DeleteButton from '../components/DeleteButton';
import { Link, navigate} from '@reach/router';
import axios from 'axios';


const UpdateView = props => {
    const { id } = props;
    const [author, setAuthor] = useState({});
    const [loaded, setLoaded] = useState(false);

    useEffect(() => {
        axios.get('http://localhost:8000/api/author/' + id)
        .then(response => {
            if (response.data.name === "CastError" ){
                window.alert("We're sorry, but we could not find the author you are looking for. Would you like to add this author to our database?");
                window.location = '/new';
            }
            else{
            setAuthor(response.data)
            setLoaded(true);
            }
        })
        .catch(err => {
            console.log(err)
        });
    })
    const onSubmitHandler = (e, name) => {
        e.preventDefault();
        axios.put('http://localhost:8000/api/author/' + id, name)
            .then(response => {
                navigate('/');
            // window.location.reload(false);
        })
        .catch(err => {
            console.log(err);
        })
    }
    return (
        <div>
            <Link to="/">Home</Link>
            <p>Edit this author: {author.name} {id}</p>
            {loaded &&
            <AuthorForm
            onSubmitHandler = {onSubmitHandler}
            initialName = {author.name}
            />}
            <DeleteButton/>
        </div>
    )

}

export default UpdateView;
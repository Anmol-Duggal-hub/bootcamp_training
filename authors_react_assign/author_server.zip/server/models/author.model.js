const mongoose = require('mongoose');
const AuthorSchema = new mongoose.Schema({
    name: { type: String, required: [true, "Please enter a Name!"], minlength:[3, "Name should be greater than 2 characters"] }
}, { timestamps: true });
module.exports.Author = mongoose.model('Author', AuthorSchema);